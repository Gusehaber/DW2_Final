/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controles;

import DAOs.DAOMarca;
import DAOs.DAOProduto;
import DAOs.DAOVenda;
import DAOs.DAOVendaHasProduto;
import Entidades.Marca;
import Entidades.Produto;
import Entidades.Venda;
import Entidades.VendaHasProduto;
import Entidades.VendaHasProdutoPK;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author a1712004
 */
@WebServlet(name = "CadastroVendaServlet", urlPatterns = {"/CadastroES"})
public class CadastroESServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
            DAOProduto daoProduto = new DAOProduto();
            Produto produto = new Produto();
            DAOMarca daoMarca = new DAOMarca();
            DAOVenda daoVenda = new DAOVenda();
            Venda venda = new Venda();
            VendaHasProduto vhp = new VendaHasProduto();
            VendaHasProdutoPK vhpk = new VendaHasProdutoPK();
            DAOVendaHasProduto daoVHP = new DAOVendaHasProduto();
            
            vhp.setVendaHasProdutoPK(vhpk);
            
        try (PrintWriter out = response.getWriter()) {
            
            
            int id = Integer.valueOf(request.getParameter("IdProduto"));
            produto = daoProduto.obter(id);
            
            Produto paux = daoProduto.obter(id);
            int qaux = paux.getQuantidadeProduto();
            
            Integer quantidade = Integer.valueOf(request.getParameter("QuantidadeProduto"));
            Float preco = Float.valueOf(request.getParameter("PrecoProduto"));
            Integer idMarca = new Integer(request.getParameter("MarcaProduto"));
            
            Marca marca = daoMarca.listByIdMarca(idMarca).get(0);
            
            produto.setQuantidadeProduto(quantidade);
            produto.setPrecoProduto(preco);
            produto.setImagemProduto("/caminho");
            produto.setMarcaidMarca(marca);
            
            if (quantidade == 0 && preco ==0) {
             daoProduto.remover(produto);
            }else{
            daoProduto.atualizar(produto);
            }
            String data = request.getParameter("DataVenda");
            venda.setData(data);
            daoVenda.inserir(venda);
            
            int aux = (qaux-quantidade)*-1;
            vhpk.setProdutoidProduto(produto.getIdProduto());
            vhpk.setVendaIdvenda(venda.getIdvenda());
            vhp.setQuantidadeProduto(aux);
            vhp.setPrecoVenda(preco*quantidade);
            daoVHP.inserir(vhp);
            
            response.sendRedirect(request.getContextPath() + "/produto");

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
