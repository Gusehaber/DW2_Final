package DAOs;

import Entidades.VendaHasProdutoPK;
import java.util.ArrayList;
import java.util.List;

public class DAOVendaHasProdutoPK extends DAOGenerico<VendaHasProdutoPK> {

    private List<VendaHasProdutoPK> lista = new ArrayList<>();

    public DAOVendaHasProdutoPK() {
        super(VendaHasProdutoPK.class);
    }

    public static void main(String[] args) {
        DAOVendaHasProdutoPK daoVendaHasProdutoPK = new DAOVendaHasProdutoPK();
        List<VendaHasProdutoPK> listaVendaHasProdutoPK = daoVendaHasProdutoPK.list();
        for (VendaHasProdutoPK vendaHasProdutoPK : listaVendaHasProdutoPK) {
            System.out.println(vendaHasProdutoPK.getVendaIdVenda() + "-"
                    + vendaHasProdutoPK.getProdutoIdProduto());
        }
    }
}
