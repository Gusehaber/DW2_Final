package DAOs;

import Entidades.VendaHasProduto;
import Entidades.VendaHasProdutoPK;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class DAOVendaHasProduto extends DAOGenerico<VendaHasProduto> {

    private List<VendaHasProduto> lista = new ArrayList<>();

    public DAOVendaHasProduto() {
        super(VendaHasProduto.class);
    }

    public VendaHasProduto obter(VendaHasProdutoPK precoProdutoPK) {
        return em.find(VendaHasProduto.class, precoProdutoPK);
    }

    public List<VendaHasProduto> listByNome(String nome) {
        return em.createQuery("SELECT e FROM VendaHasProduto e WHERE e.produto.nomeProduto LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<VendaHasProduto> listById(int id) {
        return em.createQuery("SELECT e FROM VendaHasProduto e WHERE e.vendaHasProdutoPK.produtoIdProduto = :id").setParameter("id", id).getResultList();
    }

    public List<VendaHasProduto> listInOrderNome() {
        return em.createQuery("SELECT e FROM VendaHasProduto e ORDER BY e.produto").getResultList();
    }

    public List<VendaHasProduto> listInOrderId() {
        return em.createQuery("SELECT e FROM VendaHasProduto e ORDER BY e.vendaHasProdutoPK.produtoIdProduto").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        List<VendaHasProduto> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getVendaHasProdutoPK().getVendaIdVenda() + "-"
                    + lf.get(i).getVendaHasProdutoPK().getProdutoIdProduto() + "-"
                    + lf.get(i).getQuantidadeProduto() + "-"
                    + lf.get(i).getPrecoVenda());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOVendaHasProduto daoVendaHasProduto = new DAOVendaHasProduto();
        List<VendaHasProduto> listaVendaHasProduto = daoVendaHasProduto.list();
        for (VendaHasProduto vendaHasProduto : listaVendaHasProduto) {
            System.out.println(vendaHasProduto.getVenda().getIdVenda() + "-" 
                    + vendaHasProduto.getProduto().getIdProduto());
        }
    }
}